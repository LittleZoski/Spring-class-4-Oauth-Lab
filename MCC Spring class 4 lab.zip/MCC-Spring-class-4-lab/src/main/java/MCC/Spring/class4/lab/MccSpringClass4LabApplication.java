package MCC.Spring.class4.lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MccSpringClass4LabApplication {

	public static void main(String[] args) {
		SpringApplication.run(MccSpringClass4LabApplication.class, args);
	}

}
