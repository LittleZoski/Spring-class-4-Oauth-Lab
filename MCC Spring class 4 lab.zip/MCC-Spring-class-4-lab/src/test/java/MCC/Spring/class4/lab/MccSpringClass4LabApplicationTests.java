package MCC.Spring.class4.lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MccSpringClass4LabApplicationTests {

	@Test
	void contextLoads() {
	}

}
